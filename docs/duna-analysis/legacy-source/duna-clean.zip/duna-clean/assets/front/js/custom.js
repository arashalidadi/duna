function SnackBar(type,msg) {
    // Get the snackbar DIV
    var x = document.getElementById("snackbar");
    $('#snackbar').html(msg);
    if(type == 'success'){
      x.className = "show success";
    }else if(type == 'error'){
      x.className = "show";
    }
    // After 3 seconds, remove the show class from DIV
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}

$(document).ready(function() {
  $('.minus').click(function () {
    var $input = $('.qty');
    var count = parseInt($input.val()) - 1;
    count = count < 1 ? 1 : count;
    $input.val(count);
    $input.change();
    return false;
  });
  $('.plus').click(function () {
    var $input = $('.qty');
    max = $input.attr('max');

    number = parseInt($input.val());
    if(number < max){
        $input.val(parseInt($input.val()) + 1);
        $input.change();
    }else{
        alert('شما حداکثر '+max+' می توانید خرید نمائید');
        change = max;
    }
    return false;
  });
});


function getpersiannumber(){
  function getParentLang(node) { var defaultLang = 'fa'; var currLang = null; while(currLang === null && node.parentNode) { if (node.getAttribute && node.getAttribute('lang')) { currLang = node.getAttribute('lang'); } node = node.parentNode; } return currLang || defaultLang; } function TraceNodes(e) { if (e.nodeType == 3 && getParentLang(e) === 'fa' /* Persian */) { e.nodeValue = e.nodeValue.toPersianDigit(); } else { for (var t = 0; t < e.childNodes.length; t++) { TraceNodes(e.childNodes[t]); } } } String.prototype.toPersianDigit = function(e) { return this.replace(/\d+/g, function(t) { var n = [], r = []; for (var i = 0; i < t.length; i++) { n.push(t.charCodeAt(i)) } for (var s = 0; s < n.length; s++) { r.push(String.fromCharCode(n[s] + (!!e && e == true ? 1584 : 1728))) } return r.join("") }) }; TraceNodes(document);
}
function addCommas(nStr) {
  nStr += '';
  var x = nStr.split('.');
  var x1 = x[0];
  var x2 = x.length > 1 ? '.' + x[1] : '';
  var rgx = /(\d+)(\d{3})/;
  while (rgx.test(x1)) {
      x1 = x1.replace(rgx, '$1' + ',' + '$2');
  }
  return x1 + x2;
}


$('#headersearch').keyup(function(){
  // $('.searchresult').fadeOut();
  var input = $(this).val();
  var timeout = null;
  if(input.length >= 3){

    $.ajax({
    url : '/ajax/search',
    method : 'get',
    data : {search : input },
    dataType : 'json',
    success : function(data){
      if(data.copr != 0 || data.cobr != 0){
        $('#productresult').html('');
        $('#productresult').html(data.products);
        $('.searchresult').fadeIn();
      }else{
        $('#productresult').html('<span class="no-result-found">هیچ نتیجه ای یافت نشد</span>');
        $('.searchresult').fadeIn();
      }

    },
    error : function(data){}
  });
  }else{
    $('.searchresult').fadeOut();
  }
});

$(document).click(function (e) {
  if (!$(e.target).closest('.searchresult').length)
  {
      $('.searchresult').fadeOut();
  }
  });


  