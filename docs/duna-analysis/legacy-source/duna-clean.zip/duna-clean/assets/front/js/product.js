function searchBrand() {
    // Declare variables
    var input, filter, ul, li, a, i;
    input = document.getElementById('brandsearch');
    filter = input.value.toUpperCase();
    ul = document.getElementById("shop-brands");
    li = ul.getElementsByClassName("brand-card");

    // Loop through all list items, and hide those who don't match the search query
    for (i = 0; i < li.length; i++) {
        value = li[i].getAttribute("data-search");

        if (value.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
        } else {
          li[i].style.display = "none";
        }
    }


}
function searchBrandi() {
    // Declare variables
    var input, filter, ul, li, a, i;
    input = document.getElementById('brandsearchi');
    filter = input.value.toUpperCase();
    ul = document.getElementById("shop-brandsi");
    li = ul.getElementsByClassName("brand-cardi");

    // Loop through all list items, and hide those who don't match the search query
    for (i = 0; i < li.length; i++) {
        value = li[i].getAttribute("data-search");

        if (value.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
        } else {
          li[i].style.display = "none";
        }
    }


}

var toggler = document.getElementsByClassName("caret-li");
var i;

for (i = 0; i < toggler.length; i++) {
  toggler[i].addEventListener("click", function() {
    this.parentElement.querySelector(".nested-ul").classList.toggle("active-cat");
    this.classList.toggle("caret-down-li");
  });
}


$("#ajax-shop").submit(function(e){
    var postData = $(this).serializeArray();
    var formURL = $(this).attr("action");

    $('#loadProducts').html('');
    $('#pagination-shop').html('');

    $.ajax({
      url: formURL,
      type: 'POST',
      data: postData,
      success: function(data){
        if(data.totalcount != 0){
          $('#totalcount').html(data.totalcount);
          $('#loadProducts').html(data.display);
          window.history.pushState("", "", data.url);
          $('#pagination-shop').delay( 800 ).html(data.paginate);
          getpersiannumber();
        }else{
          window.history.pushState("", "", data.url);
          $('#loadProducts').html('<div class="not-found-product"><img src="/no-products.png" class="img-fluid" alt="هیچ محصول یافت نشد"><h3>هیچ محصولی یافت نشد</h3></div>');
        }

      },
      error: function(result){
        SnackBar('error','خطایی رخ داده است مجددا تلاش نمائید');
      }
    });
e.preventDefault();
});
$('.avacheck').on('change', function(){
  $('#ajax-shop').submit();
});
$('.offcheck').on('change', function(){
  $('#ajax-shop').submit();
});
$('.brand-select').on('change', function(){
  $('#ajax-shop').submit();
});
$('.sortbyshop').on('change', function(){
  $('#ajax-shop').submit();
});
function changefilter(filter){
    if(filter == 'newest'){
        value = 'جدیدترین';
    }else if(filter == 'popular-item'){
        value = 'محبوب ترین';
    }else if(filter == 'highest-sales'){
        value = 'پرفروش ترین';
    }else if(filter == 'lowest-price'){
        value = 'ارزان ترین';
    }else if(filter == 'highest-price'){
        value = 'گران ترین';
    }

    
    $('.sort-by-dropdown ul').find('.active').removeClass("active");
    $('#'+filter).addClass('active');
    $('.sort-by-dropdown-wrap').html('<span> '+value+' <i class="fi-rs-angle-small-down"></i></span>')
    $('.sort-by-dropdown').removeClass('show');
    $('#filterValue').val(filter);
    $('#ajax-shop').submit();
}

$('.searchinshop').keypress(function (e) {
if (e.which == 13) {
  $('#ajax-shop').submit();
  return false; 
}
});



function deleteitemcart(key){
  $.ajax({
      url : '/cart/ajax/delete-cart-item',
      data : {key : key},
      method : 'POST',
      dataType : 'json',
      success : function(result){
        total = $('#total-headersave').val();
        subtot = $('#item-'+key).data('subtot');
        $('#cartbadge').html(result.count);
        if(result.count == 0){
          $('#cart-overview').html('<div id="main-cart"><div class="emptycart-text"><h5>سبد خرید خالی است</h5></div></div>');
          $('#cartbadge').html(0);
          $('#totalbadge').html(0);
        }
        newtotal = parseInt(total) - parseInt(subtot);
        $('#headercart-total').html('<h4>جمع کل: <span>'+addCommas(newtotal)+' تومان</span></h4>');
        $('#total-headersave').val(newtotal);
        $('#item-'+key).remove();

        getpersiannumber();

      }
  });
}

$('#add-to-cart').submit(function(e){
  e.preventDefault();
  var postData = $(this).serializeArray();
  var formURL = $(this).attr("action");
  $('.loader').show();
  $.ajax({
      url : formURL,
      method : 'POST',
      data : postData,
      dataType : 'json',
      success : function(data) {
      $('.cartmodal-footer').fadeIn(0);
      $('.addtocart-number-input').val(1);
      $('#cart-overview').html(data.cart);
      $('#cartbadge').html(data.count);
      $('#totalbadge').html(data.total);
      $('#total-headersave').val(data.total);

      SnackBar('success',data.msg);
      getpersiannumber();

      },
      error : function(data) {
      SnackBar('error','خطایی رخ داده است مجددا تلاش نمائید');
      }
  });
  e.preventDefault();
});

$(document).on('change', '.option_id', function(){

opt = $('#option_id').val();
productid = $('#productID').val();
$.ajax({
url : '/ajax/get-option-details',
method : 'GET',
data : {opt:opt , productid:productid },
dataType : 'json',
success : function(data) {

if(data.opt.price){
  if(data.opt.salesprice){
    percent = parseInt((1-(data.opt.salesprice / data.opt.price))*100);
    price = addCommas(data.opt.price);
    salesprice = addCommas(data.opt.salesprice);
    $('.pr-price').html('<div class="current-price text-brand">'+salesprice+' تومان</div><div><span class="save-price font-md color3 ml-15">'+percent+'% تخفیف</span><span class="old-price font-md ml-15">'+price+' تومان</span></div>');
    
  }else{
      price = addCommas(data.opt.price);
    $('.pr-price').html('<div class="current-price text-brand">'+price+' تومان</div>');
  }

}else{
  $('.pr-price').html('');
}
getpersiannumber();

if(data.opt.avacheck){

    if(data.opt.ava){
        $('.qty').attr('max',data.opt.ava);
        $('.FormAjaxAddtoCart').fadeIn(0);
        $('.pr-price').fadeIn(0);
        $('#outofstockForm').fadeOut();
        $('#Cart-Form-Box').fadeIn();


    }else{
        $('.pr-price').fadeOut(0);
        $('.qty').attr('max','1');
        $('#optionsSelected').val(opt);
        $('#outofstockForm').fadeIn();
        $('.FormAjaxAddtoCart').fadeOut(0);

    }
}else{
     $('.pr-price').fadeOut(0);
     $('.qty').attr('max','1');
     $('.FormAjaxAddtoCart').fadeOut(0);
     $('#optionsSelected').val(opt);
     $('#outofstockForm').fadeIn();


}

},
error : function(data) {

  SnackBar('error','خطایی رخ داده است مجددا تلاش نمائید');

}
});

});    