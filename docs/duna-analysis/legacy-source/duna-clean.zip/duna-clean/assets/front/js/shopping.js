$('#gotopay').submit(function(){
  add = $('#addressinput').val();
   if(add == '' || add == null){
       
       SnackBar('error','لطفا یک نشانی وارد کنید یا انتخاب کنید');

       return false;
   }
   
   $(".btn-gocheckout", this)
     .html("لطفا منتظر بمانید ...")
     .attr('disabled', 'disabled');
   return true;
});


$(document).ready(function () {
   id = $('.address-radio:radio:checked').val();
   $('#addressinput').val(id);
});


$("input[type=radio][name=address_id]").on('change', function() {

 id = $('.address-radio:radio:checked').val();

 if(id){
     $('#addressinput').val(id);
       
     $(".address-box-div").removeClass("selectAddress");
     $('#address-'+id).addClass('selectAddress');
 }

});    

function getCityList(elid,city_id){
 id = $('#state-select-'+elid+' option:selected').val();

 $.ajax({
   url : '/ajax/get-cities',
   method : 'GET',
   data : {id:id},
   dataType : 'json',
   success : function(result) {
     $('#city-select-'+elid).html('<option value="">شهر را انتخاب کنید</option>');
     $.each(result.cities, function(i,val,select){
       name = val.fname;

       if(city_id == val.id){

           $('#city-select-'+elid).append('<option value="'+val.id +'">'+name+'</option>');
     
           $('#city-select-'+elid+' option[value="'+city_id+'"]').prop('selected', true);
       }else{
           $('#city-select-'+elid).append('<option value="'+val.id +'">'+name+'</option>');
       }
       

       
     });
   },
   error : function(data) {
       
       SnackBar('error','خطایی رخ داده است مجددا تلاش کنید');

   }
 });
}


$('#AddAddressForm').submit(function(e){



city = $('#city-select-0 option:selected').val();
state = $('#state-select-0 option:selected').val();

   if(state == '' || state == null){
       
       SnackBar('error','لطفا استان را انتخاب کنید');

       return false;
   }
   if(city == '' || city == null){
       
       SnackBar('error','لطفا شهر را انتخاب کنید');

       return false;
   }
   
   return true;
   
   e.preventDefault();
});    


function removeitemfromcart(key){
    $.ajax({
        url : '/cart/ajax/delete-cart-item',
        data : {key : key},
        method : 'POST',
        dataType : 'json',
        success : function(result){
          if(result.count == 0){
            $('#cartPageBody').html('<h4 class="emptycart"><i class="fi-rs-shopping-cart"></i><br> سبد خرید خالی است</h4>');
          }else{
            subtot = $('#subtotal-'+key).data('value');
            total = $('#total').data('value');
            newtotal = parseInt(total) - parseInt(subtot);
            $('#total').html(addCommas(newtotal));
            $('#total').attr('data-value',newtotal);

            $('#item-'+key).fadeOut(0);

            getpersiannumber();

            SnackBar('success','محصول با موفقیت از سبد خرید حذف شد');
  
          }
  
        }
    });
  }
  function changecartnumber(key){
    num = $('#num-'+key).val();
    $.ajax({
        url : '/cart/ajax/change-cart-item',
        data : {key : key ,num:num},
        method : 'POST',
        dataType : 'json',
        success : function(result){
            subtot = $('#subtotal-'+key).data('value');
            total = $('#total').data('value');
            price = $('#price-'+key).val();
            newtotal = parseInt(total) - parseInt(subtot);
            unit = $('#unit-'+key).val();
            sbtotal = price*num;
  
  
            newtotal = newtotal + sbtotal;
  
            $('#total').html(addCommas(newtotal));
            $('#total').attr('data-value',newtotal);
            $('#subtotal-'+key).html(addCommas(sbtotal));
            $('#subtotal-'+key).attr('data-value',sbtotal);
  
            getpersiannumber();


  
        }
    });
  }

  